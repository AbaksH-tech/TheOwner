package psh;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPotionEffectEvent;
import org.bukkit.event.player.*;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;

public class TheOwner extends JavaPlugin implements Listener {

    private FileConfiguration messages;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveLang("messages_ru_RU.yml");
        saveLang("messages_en_US.yml");
        loadMessages();

        Bukkit.getPluginManager().registerEvents(this, this);
    }

    /* ================= LANGUAGE ================= */

    private void saveLang(String fileName) {
        File file = new File(getDataFolder(), fileName);
        if (!file.exists()) saveResource(fileName, false);
    }

    private void loadMessages() {
        String lang = getConfig().getString("language", "ru_RU");
        messages = YamlConfiguration.loadConfiguration(
                new File(getDataFolder(), "messages_" + lang + ".yml"));
    }

    /* ================= RELOAD COMMAND ================= */

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!command.getName().equalsIgnoreCase("theowner")) return false;

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {

            if (sender instanceof Player p && !p.hasPermission("theowner.reload")) {
                sender.sendMessage("§cНет прав.");
                return true;
            }

            reloadConfig();
            loadMessages();
            sender.sendMessage("§aTheOwner перезагружен.");
            return true;
        }

        sender.sendMessage("§e/theowner reload");
        return true;
    }

    /* ================= UTILS ================= */

    private boolean hasBypass(Player p) {
        return p.hasPermission("theowner.bypass");
    }

    private boolean isBlocked(Player target, String path) {
        return getConfig().contains("players." + target.getName() + "." + path)
                && !getConfig().getBoolean("players." + target.getName() + "." + path);
    }

    /* ================= COMMAND BLOCK ================= */

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player sender = e.getPlayer();
        if (hasBypass(sender)) return;

        if (!getConfig().isConfigurationSection("players")) return;

        String msg = e.getMessage().toLowerCase();

        for (String name : getConfig().getConfigurationSection("players").getKeys(false)) {

            if (!msg.contains(" " + name.toLowerCase())) continue;

            Player target = Bukkit.getPlayerExact(name);
            if (target == null) return;

            // 🔥 ВАЖНО: разрешаем делать всё с собой
            if (sender.equals(target)) return;

            if (!getConfig().getBoolean("players." + name + ".commands")) {
                e.setCancelled(true);
                sender.sendMessage(messages.getString("blocked", "§cBlocked"));
                return;
            }
        }
    }

    /* ================= TELEPORT ================= */

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        Player target = e.getPlayer();

        // сам себя телепортирует — можно
        if (e.getFrom().equals(e.getTo())) return;

        if (isBlocked(target, "teleport")) e.setCancelled(true);
    }

    /* ================= GAMEMODE ================= */

    @EventHandler
    public void onGamemode(PlayerGameModeChangeEvent e) {
        Player target = e.getPlayer();

        // сам себе меняет — можно
        if (target.equals(e.getPlayer())) return;

        if (isBlocked(target, "gamemode")) e.setCancelled(true);
    }

    /* ================= KICK ================= */

    @EventHandler
    public void onKick(PlayerKickEvent e) {
        Player target = e.getPlayer();

        if (isBlocked(target, "kick")) e.setCancelled(true);
    }

    /* ================= DAMAGE ================= */

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player target)) return;

        if (e instanceof EntityDamageByEntityEvent ed) {
            Entity damager = ed.getDamager();

            // сам себя бьёт — не блокируем
            if (damager.equals(target)) return;

            if (damager instanceof Player) {
                if (isBlocked(target, "damage.players")) e.setCancelled(true);
            } else {
                if (isBlocked(target, "damage.mobs")) e.setCancelled(true);
            }
        } else {
            if (isBlocked(target, "damage.environment")) e.setCancelled(true);
        }
    }

    /* ================= EFFECTS ================= */

    @EventHandler
    public void onEffect(EntityPotionEffectEvent e) {
        if (!(e.getEntity() instanceof Player target)) return;

        if (isBlocked(target, "effects")) e.setCancelled(true);
    }
}
